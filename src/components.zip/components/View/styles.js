import {StyleSheet} from "react-native";


export default StyleSheet.create({
    view: {
        paddingVertical: 10,
        backgroundColor: 'red'
    }
})
