export {SegmentControl}from "./SegmentControl"
